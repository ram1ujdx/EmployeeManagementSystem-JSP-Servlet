package com.ems.util;

public class InvalidLengthException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public InvalidLengthException(String s)
	{
		super(s);
	}

}
