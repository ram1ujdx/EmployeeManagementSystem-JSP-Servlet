package com.ems.util;

public class InvalidSalaryException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidSalaryException(String s)
	{
		super(s);
	}
}
